#include <stdio.h>

int main(void) {
	
	double velo, dist, time;

	time = dist / velo;

	return 0;
}