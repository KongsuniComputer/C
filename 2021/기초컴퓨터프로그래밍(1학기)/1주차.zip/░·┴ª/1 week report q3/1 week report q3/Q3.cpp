#include <stdio.h>

int main(void) {
	
	printf("7 + 8 = %d \n", 7 + 8);

	return 0;
}