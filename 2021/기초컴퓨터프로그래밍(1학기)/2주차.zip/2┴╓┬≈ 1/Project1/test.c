#include <stdio.h>

int main(void)
{
	printf("������!!\n\n");

	printf("1��\n");
	for (int i = 1; i < 10; i++)
	{
		printf("1 * %d = %d\n\n", 1, i, 1 * i);
	}

	printf("2��\n");
	for (int i = 1; i < 10; i++)
	{
		printf("2 * %d = %d\n\n", i, 2 * i);
	}

	printf("3��\n");
	for (int i = 1; i < 10; i++)
	{
		printf("3 * %d = %d\n\n", i, 3 * i);
	}

	printf("4��\n");
	for (int i = 1; i < 10; i++)
	{
		printf("4 * %d = %d\n\n", i, 4 * i);
	}

	printf("5��\n");
	for (int i = 1; i < 10; i++)
	{
		printf("5 * %d = %d\n\n", i, 5 * i);
	}
	
	printf("6��\n");
	for (int i = 1; i < 10; i++)
	{
		printf("6 * %d = %d\n\n", i, 6 * i);
	}

	printf("7��\n");
	for (int i = 1; i < 10; i++)
	{
		printf("7 * %d = %d\n\n", i, 7 * i);
	}

	printf("8��\n");
	for (int i = 1; i < 10; i++)
	{
		printf("8 * %d = %d\n\n", i, 8 * i);
	}

	printf("9��\n");
	for (int i = 1; i < 10; i++)
	{
		printf("9 * %d = %d\n\n", i, 9 * i);
	}
	return 0;
}
