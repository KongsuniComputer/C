#include <stdio.h>

int main(void) {
	
	int x;
	int y;
	int sum;

	x = 100;
	y = 200;

	sum = x + y;

	printf("�� ���� �� : %d", sum);

	return 0;
}